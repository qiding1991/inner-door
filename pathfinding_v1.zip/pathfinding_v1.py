
def pathFinding_v1():
    """
    parameter:
    path_nodes: nodes of the path, type: list
    """

    
    
    path_nodes = [[308242561.9612449,506914096.89033026],[308242561.9612449,506961415.9401813]]

    return path_nodes
